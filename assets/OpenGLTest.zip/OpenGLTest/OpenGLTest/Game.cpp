//////////////////////////////////////////////////////////// 
// Headers 
//////////////////////////////////////////////////////////// 

#ifdef _DEBUG 
#pragma comment(lib,"sfml-graphics-d.lib") 
#pragma comment(lib,"sfml-audio-d.lib") 
#pragma comment(lib,"sfml-system-d.lib") 
#pragma comment(lib,"sfml-window-d.lib") 
#pragma comment(lib,"sfml-network-d.lib") 
#else 
#pragma comment(lib,"sfml-graphics.lib") 
#pragma comment(lib,"sfml-audio.lib") 
#pragma comment(lib,"sfml-system.lib") 
#pragma comment(lib,"sfml-window.lib") 
#pragma comment(lib,"sfml-network.lib") 
#endif 
#pragma comment(lib,"opengl32.lib") 
#pragma comment(lib,"glu32.lib") 

#include "SFML/Graphics.hpp" 
#include "SFML/OpenGL.hpp" 
#include <iostream> 
#include "Game.h"


Game::Game() : window(VideoMode(800, 600), "OpenGL")
{

}

Game::~Game()
{
}

void Game::run()
{
	initialize();

	Event event;

	while (isRunning) {
		while (window.pollEvent(event))
		{
			if (event.type == Event::Closed)
			{
				isRunning = false;
				window.close();
			}
			if (event.type == Event::KeyPressed && event.key.code == Keyboard::Escape)
			{
				isRunning = false;
				window.close();
			}
		}
		update();
		draw();
	}
}

void Game::initialize()
{
	isRunning = true;
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f); 
	glMatrixMode(GL_PROJECTION); 
	glLoadIdentity(); 
	gluPerspective(45.0, window.getSize().x / window.getSize().y, 1.0, 500.0); 
	glMatrixMode(GL_MODELVIEW);
}

void Game::update()
{    
	

}

void Game::draw()
{
	glTranslated(0.0f, 0.0f, 0.0f); //shift to original position
	glRotated(0.1f, 0.0f, 0.0f, 1.0f); // rotate
	glScalef(1.0f, 1.0f, 1.000001f);// shift centre to origin

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClear(GL_COLOR_BUFFER_BIT);

	glBegin(GL_TRIANGLES);
	{
		glVertex3f(0.0, 1.0, -12.0);
		glColor3d(1, 0, 1);
		glVertex3f(-1.0, -1.0, -12.0); 
		glColor3d(0, 0, 1);
		glVertex3f(1.0, -1.0, -12.0);
		glColor3d(1, 0, 0);
	}
	glEnd();

	glBegin(GL_QUADS);
	{
		glVertex3f(1,1,-12);
		glVertex3f(2,1,-12);
		glVertex3f(2,2,-12);
		glVertex3f(1,2,-12);
	}
	glEnd();

	glBegin(GL_POINT);
	{
		glVertex3f(1, 3, -12);
	}
	glEnd();

	glBegin(GL_LINE_STRIP);
	{
		glVertex3f(1, 1, -12);
		glVertex3f(2, 2, -12);
		glVertex3f(3, 3, -12);
	}
	glEnd();

	glBegin(GL_POLYGON);
	{
		glVertex3f(-2, -1, -12);
		glVertex3f(-1, -1, -12);
		glVertex3f(0, -3, -12);
		glVertex3f(-3,-3,-12);
	}
	glEnd();

	glBegin(GL_LINES);
	{
		glVertex3f(3, -3, -12);
		glVertex3f(-3, -3, -12);
	}
	glEnd();

	glBegin(GL_LINE_LOOP);
	{
		glVertex3f(2,4,-12);
		glVertex3f(-4,4,-12);
		glVertex3f(-4,-2,-12);
	}
	glEnd();

	glBegin(GL_TRIANGLE_FAN);
	{
		glVertex3f(1, 3, -12);
		glVertex3f(-3, 3, -12);
		glVertex3f(-3, -1, -12);
	}
	glEnd();

	glBegin(GL_TRIANGLE_STRIP);
	{
		glVertex3f(-1, -3, -12);
		glVertex3f(3, -3, -12);
		glVertex3f(3, 1, -12);
	}
	glEnd();

	glBegin(GL_QUAD_STRIP);
	{
		glVertex3f(4, 4, -12);
		glVertex3f(5, 4, -12);
		glVertex3f(5, 5, -12);
		glVertex3f(4, 5, -12);
	}
	glEnd();

	window.display();
};


void Game::unload()
{
	cout << "cleaning up" << endl;
}
