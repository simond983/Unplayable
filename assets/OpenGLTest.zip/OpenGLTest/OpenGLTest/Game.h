#pragma once
#include <SFML/Window.hpp>
#include <SFML/OpenGL.hpp>
#include <gl/GL.h>
#include <gl\GLU.h>

using namespace std;
using namespace sf;

class Game
{
public:
	Game();
	~Game();
	void run();

private:
	Window window;
	void update();
	void draw();
	bool isRunning = false;
	void initialize();
	void unload();
};


