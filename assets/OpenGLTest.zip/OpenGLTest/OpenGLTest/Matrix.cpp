#include "Matrix.h"


Matrix::Matrix()
{// The class has nine variables, 3 rows and 3 columns
	double A11 = 0.0;
	double A12 = 0.0;
	double A13 = 0.0;
	double A21 = 0.0;
	double A22 = 0.0;
	double A23 = 0.0;
	double A31 = 0.0;
	double A32 = 0.0;
	double A33 = 0.0;
}

Matrix::~Matrix() {}


Matrix::Matrix(Vector Row1, Vector Row2, Vector Row3)
{  // To allow 3 rows of vectors to be declared as a matrix
	A11 = Row1.x;
	A12 = Row1.y;
	A13 = Row1.z;
	A21 = Row2.x;
	A22 = Row2.y;
	A23 = Row2.z;
	A31 = Row3.x;
	A32 = Row3.y;
	A33 = Row3.z;
}
		// Constructor 3
Matrix::Matrix(double _A11, double _A12, double _A13,
			double _A21, double _A22, double _A23,
			double _A31, double _A32, double _A33)
{// to allow nine double values
	A11 = _A11;
	A12 = _A12;
	A13 = _A13;
	A21 = _A21;
	A22 = _A22;
	A23 = _A23;
	A31 = _A31;
	A32 = _A32;
	A33 = _A33;
}

Vector Matrix::operator *(Vector &V1)
{// An overloaded operator * to return the  product of the matrix by a vector
	return Vector(A11 * V1.x + A12 * V1.y + A13 * V1.z,
		A21 * V1.x + A22 * V1.y + A23 * V1.z,
		A31 * V1.x + A32 * V1.y + A33 * V1.z);
}

Matrix Matrix::transpose()
{// a method to transpose a given matrix
	return Matrix(A11, A21, A31,
		A12, A22, A32,
		A13, A23, A33);
}

Matrix Matrix::operator +(Matrix M)
{// An overloaded operator + to return the  sum of two matrix 
	return Matrix(A11 + M.A11, A12 + M.A12, A13 + M.A13,
		A21 + M.A21, A22 + M.A22, A23 + M.A23,
		A31 + M.A31, A32 + M.A32, A33 + M.A33);
}

Matrix Matrix::operator -(Matrix M)
{// An overloaded operator * to return the  difference of two matrix
	return Matrix(A11 - M.A11, A12 - M.A12, A13 - M.A13,
		A21 - M.A21, A22 - M.A22, A23 - M.A23,
		A31 - M.A31, A32 - M.A32, A33 - M.A33);
}

Matrix Matrix::operator *(double x)
{// An overloaded operator * to return the  product of the matrix by a scalar
	Matrix answer = Matrix();
	answer.A11 = A11 * x;
	answer.A12 = A12 * x;
	answer.A13 = A13 * x;

	answer.A21 = A21 * x;
	answer.A22 = A22 * x;
	answer.A23 = A23 * x;

	answer.A31 = A31 * x;
	answer.A32 = A32 * x;
	answer.A33 = A33 * x; ;

	return answer;
}

Matrix Matrix::operator *(Matrix M)
{// An overloaded operator * to return the  product of two matrix
	Matrix answer = Matrix();
	answer.A11 = row(0) * M.column(0);
	answer.A12 = row(0) * M.column(1);
	answer.A13 = row(0) * M.column(2);

	answer.A21 = row(1) * M.column(0);
	answer.A22 = row(1) * M.column(1);
	answer.A23 = row(1) * M.column(2);

	answer.A31 = row(2) * M.column(0);
	answer.A32 = row(2) * M.column(1);
	answer.A33 = row(2) * M.column(2);

	return answer;
}

double Matrix::determinant()
{// method to return the determinant of a 3x3 matrix
	//                     
	return (A11 * A22 * A33 - A11 * A32 * A23 + A21 * A32 * A13 - A31 * A22 * A13 + A31 * A12 * A23 - A21 * A12 * A33);
}

Vector Matrix::row(int i)
{
	// a method to return as Row as vector3 0 == first row, default == last row
	switch (i)
	{
	case 0:
		return Vector(A11, A12, A13);
	case 1:
		return Vector(A21, A22, A23);
	case 2:
		default:
		return Vector(A31, A32, A33);
	}
}

Vector Matrix::column(int i)
{// a method to return as column as vector3 0 == first column, default == last column
	switch (i)
	{
	case 0:
		return Vector(A11, A21, A31);
	case 1:
		return Vector(A12, A22, A32);
	case 2:
	default:
		return Vector(A13, A23, A33);
	}
}


Matrix Matrix::inverse()
{
	// method to return the inverse of a matrix if exists else zero vector
	double det = determinant();
	if (det == 0)
		return Matrix();
	else
	{
		double scale = 1 / det;
		Matrix answer = Matrix();
		answer.A11 = scale * (A22 * A33 - A23 * A32); 
		answer.A12 = scale * (A13 * A32 - A12 * A33); 
		answer.A13 = scale * (A12 * A23 - A13 * A22); 

		answer.A21 = scale * (A23 * A31 - A21 * A33); 
		answer.A22 = scale * (A11 * A33 - A13 * A31); 
		answer.A23 = scale * (A13 * A21 - A11 * A23); 


		answer.A31 = scale * (A21 * A32 - A22 * A31); // dh-eg
		answer.A32 = scale * (A12 * A31 - A11 * A32); // bg-ah
		answer.A33 = scale * (A11 * A22 - A12 * A21); // ae-bd

		return answer;
	}

}

Matrix Matrix::rotation(int _angle)
{
	double radians = PI / 180 * _angle;
	Matrix answer = Matrix();
	answer.A11 = cos(radians);
	answer.A12 = sin(radians);
	answer.A13 = 0;
	answer.A21 = -sin(radians);
	answer.A22 = cos(radians);
	answer.A23 = 0;
	answer.A31 = 0;
	answer.A32 = 0;
	answer.A33 = 1;

	return answer;
}

Matrix Matrix::translate(int dx, int dy)
{
	Matrix answer = Matrix();
	answer.A11 = 1;
	answer.A12 = 0;
	answer.A13 = 0;
	answer.A21 = 0;
	answer.A22 = 1;
	answer.A23 = 0;
	answer.A31 = dx;
	answer.A32 = dy;
	answer.A33 = 1;

	return answer;
}

Matrix Matrix::scale(int dx, int dy)
{
	Matrix answer = Matrix();
	answer.A11 = (double)dx / 100;
	answer.A12 = 0;
	answer.A13 = 0;
	answer.A21 = 0;
	answer.A22 = (double)dy / 100;
	answer.A23 = 0;
	answer.A31 = 0;
	answer.A32 = 0;
	answer.A33 = 1;

	return answer;
}

Matrix Matrix::operator -()
{
	Matrix answer = Matrix(-A11, -A12, -A13, -A21, -A22, -A23, -A31, -A32, -A33);
	return answer;
}

Matrix Matrix::rotationX(int _angle)
{
	double radians = PI / 180 * _angle;
	Matrix answer = Matrix();
	answer.A11 = 1;
	answer.A12 = 0;
	answer.A13 = 0;
	answer.A21 = 0;
	answer.A22 = cos(radians);
	answer.A23 = -sin(radians);
	answer.A31 = 0;
	answer.A32 = sin(radians);
	answer.A33 = cos(radians);

	return answer;
}

Matrix Matrix::rotationY(int _angle)
{
	double radians = PI / 180 * _angle;
	Matrix answer = Matrix();
	answer.A11 = cos(radians);
	answer.A12 = 0;
	answer.A13 = sin(radians);
	answer.A21 = 0;
	answer.A22 = 1;
	answer.A23 = 0;
	answer.A31 = -sin(radians);
	answer.A32 = 0;
	answer.A33 = cos(radians);

	return answer;
}

Matrix Matrix::rotationZ(int _angle)
{
	double radians = PI / 180 * _angle;
	Matrix answer =  Matrix();
	answer.A11 = cos(radians);
	answer.A12 = -sin(radians);
	answer.A13 = 0;
	answer.A21 = sin(radians);
	answer.A22 = cos(radians);
	answer.A23 = 0;
	answer.A31 = 0;
	answer.A32 = 0;
	answer.A33 = 1;

	return answer;
}

Matrix Matrix::scale3D(int dx)
{
	Matrix answer = Matrix();
	answer.A11 = (double)dx / 100;
	answer.A12 = 0;
	answer.A13 = 0;
	answer.A21 = 0;
	answer.A22 = (double)dx / 100;
	answer.A23 = 0;
	answer.A31 = 0;
	answer.A32 = 0;
	answer.A33 = (double)dx / 100;

	return answer;
}
	
