#pragma once
#include "Vector.h"
#include <math.h>

class Matrix
{
public:
	Matrix();
	Matrix(Vector Row1, Vector Row2, Vector Row3);
	Matrix(double _A11, double _A12, double _A13,
		double _A21, double _A22, double _A23,
		double _A31, double _A32, double _A33);
	Vector operator *(Vector &V1);
	Matrix transpose();
	Matrix operator +(Matrix M);
	Matrix operator -(Matrix M);
	Matrix operator *(double x);
	Matrix operator *(Matrix M);
	double determinant();
	Vector row(int i);
	Vector column(int i);
	Matrix inverse();
	Matrix rotation(int _angle);
	Matrix translate(int dx, int dy);
	Matrix scale(int dx, int dy);
	Matrix operator -();
	Matrix rotationX(int _angle);
	Matrix rotationY(int _angle);
	Matrix rotationZ(int _angle);
	Matrix scale3D(int dx);
	~Matrix();

private:
	const double PI = 2 * acos(0.0);
	double A11;
	double A12;
	double A13;
	double A21;
	double A22;
	double A23;
	double A31;
	double A32;
	double A33;
};


