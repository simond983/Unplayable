#include "Vector.h"


Vector::Vector()
{
	// The class has three variables x, y and z 
	x = 0.0f;
	y = 0.0f;
	z = 0.0f;
}
Vector::~Vector() {}

double Vector::getX()
{
	return x;
}
double Vector::getY()
{
	return y;
}
double Vector::getZ()
{
	return z; 
}

	// Constructor 2
Vector::Vector(double x1, double y1, double z1)
{ // To allow other values for X, Y and Z to be declared
	x = x1;
	y = y1;
	z = z1;
}


double Vector::length()
{  // A method to return the length of the vector
	return (double)sqrt(x * x + y * y + z * z);
}
double Vector::lengthSquared()
{  // A method to return the length squared of the vector
	return (x * x + y * y + z * z);
}

void Vector::normalise()
{  // A method to reduce the length of the vector to 1.0 
   // keeping the direction the same
	if (length() > 0.0)
	{  // Check for divide by zero
		double magnit = length();
		x /= magnit;
		y /= magnit;
		z /= magnit;
	}
}

Vector Vector::operator+=(Vector &vec)
{  // An overloaded operator + to return the sum of 2 vectors
	return Vector(this->x + vec.x, this->y + vec.y, this->z + vec.z);
}

Vector Vector::operator+(Vector &vec)
{  // An overloaded operator + to return the sum of 2 vectors
	return Vector(this->x + vec.x, this->y + vec.y, this->z + vec.z);
}

Vector Vector::operator-=(Vector &vec)
{  // An overloaded operator - to return the difference of 2 vectors
	return Vector(this->x - vec.x, this->y - vec.y, this->z - vec.z);
}

Vector Vector::operator-(Vector &vec)
{  // An overloaded operator - to return the difference of 2 vectors
	return Vector(this->x - vec.x, this->y - vec.y, this->z - vec.z);
}

double Vector::operator*=(Vector &vec)
{  // An overloaded operator - to return the difference of 2 vectors
	return double(this->x * vec.x + this->y * vec.y + this->z * vec.z);
}

double Vector::operator*(Vector &vec)
{  // An overloaded operator - to return the difference of 2 vectors
	return double(this->x * vec.x + this->y * vec.y + this->z * vec.z);
}

Vector Vector::operator -(Vector V)
{// An overloaded operator - to return the negation of a single vector
	Vector answer = Vector(0, 0, 0);
	Vector V1 = answer;
	V1.x = -V.x;
	V1.y = -V.y;
	V1.z = -V.z;
	return V1;
}

Vector Vector::operator *(double k)
{// An overloaded operator * to return the product of a scalar by a vector
	return Vector(x * (float)k, y * (float)k, z * (float)k);
}

Vector Vector::operator ^(Vector V)
{// An overloaded operator ^ to return the vector product of 2 vectors
	return Vector(y * V.z - z * V.y, z * V.x - x * V.z, x * V.y - y * V.x);
}

std::stringstream Vector::toString()
{
	std::stringstream ss;
	ss << "(" << x << "," << y << "," << z << ")";
	return ss;
}

