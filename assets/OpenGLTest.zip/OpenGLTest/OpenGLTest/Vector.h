#pragma once

#include <math.h>
#include <sstream>
#include <iostream>

class Vector
{
public:
	Vector();
	~Vector();
	double getX();
	double getY();
	double getZ();
	Vector(double x1, double y1, double z1);
	double length();
	double lengthSquared();
	void normalise();

	Vector operator+(Vector &vec);
	Vector operator+=(Vector &vec);

	Vector operator-(Vector &vec);
	Vector operator-=(Vector &vec);

	double operator*(Vector &vec);
	double operator*=(Vector &vec);

	Vector operator-(Vector V);
	Vector operator*(double k);
	Vector operator^(Vector V);
	std::stringstream toString();
	double x;
	double y;
	double z;

private:

};

