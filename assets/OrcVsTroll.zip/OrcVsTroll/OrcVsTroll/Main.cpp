#include <iostream>
#include "Monster.h"

using namespace std;
Troll troll;
Orc orc;
int orcDamage;	//Creates the orcs damage
int trollDamage;	//Creates the trolls damage

//Main function
int main()
{
	cout << ("In the magical land of Kaladesh, there was a great struggle for power. A mighty troll by the name of Azrael took up arms against a powerful orc called Hondur.  This is the tale of their battle!") << endl;

	//While loop to make sure both monsters are still alive
	while (troll.getAlive() && orc.getAlive())
	{
		if (orc.getEnergy() > 3)	//Checks if the orc has enough energy to attack
		{
			orcDamage = orc.attack();	//Calculates the orcs attack
			cout << "The orc hits the troll for " << orcDamage << " damage." << endl;
			troll.setHealth((troll.getHealth() - orcDamage));	//Deals damage to the troll equal to the attack damage
		}

		if (troll.getEnergy() > 3 && troll.getHealth() > 0)	//Checks if the troll has enough energy to attack
		{
			trollDamage = troll.attack();	//Calculates the trolls attack
			cout << "The troll hits the orc for " << trollDamage << " damage." << endl;
			orc.setHealth((orc.getHealth() - trollDamage));	//Deals damage to the orc equal to the attack damage
		}
		if (orc.getHealth() <= 0)	//Checks if the orc is dead
		{
			orc.setAlive(false);	//Sets the orc to be dead
		}

		if (troll.getHealth() <= 0)	//Checks if the troll is dead
		{
			troll.setAlive(false);	//Sets the troll to be dead
		}

		int energy = orc.getEnergy() + 1;	//Increments the energy of the orc
		orc.setEnergy(energy);		//Sets the new energy level to be the orc energy
		energy = troll.getEnergy() + 1;	//Increments the energy of the troll
		troll.setEnergy(energy);	//Sets the new energy level to be the trolls energy
	}

	if (!troll.getAlive())	//Checks if the troll is dead
	{
		cout << "The orc wins!" << endl;	//Outputs that the orc is dead
	}

	if (!orc.getAlive() && troll.getAlive())	//Checks if the orc is dead
	{
		cout << "The troll wins!" << endl;	//Outputs that the troll wins
	}

	system("pause");
}