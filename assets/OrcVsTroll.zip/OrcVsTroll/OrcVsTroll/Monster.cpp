#include "Monster.h"
#include <ctime>
#include <string>

//Monster class

//Monster constructor 
Monster::Monster() 

{

}

//Getter for getting alive
bool Monster::getAlive() const
{
	return m_alive;
}

//Getter for getting energy
int Monster::getEnergy() const
{
	return m_energy;
}

//Getter for getting health
int Monster::getHealth() const 
{
	return m_health;


}

//Setter for changing health
void Monster::setHealth(const int newHealth)
{
	m_health = newHealth;
}

//Setter for changing energy
void Monster::setEnergy(const int newEnergy)
{
	m_energy = newEnergy;
}

//Setter for changing alive
void Monster::setAlive(const int newAlive)
{
	m_alive = newAlive;
}

//Troll sub-class
Troll::Troll()
{
	m_health = 400;	//Sets the health of the troll
	m_strength = 50;	//Sets the strength of the troll
	m_energy = 5;		//Sets the energy of the troll
	m_alive = true;	//Sets the troll to be alive
}


Orc::Orc()
{
	m_health = 500;	//Sets the health of the orc
	m_strength = 30;	//Sets the strength of the orc
	m_energy = 10;	//Sets the health of the orc
	m_alive = true;
}

//Function for getting the trolls attack
int Troll::attack()
{
		srand(time(NULL));
		int attack = (((rand() % 100) + 1) + m_strength) + 2;	//calculates the damage done
		return attack;
}

//Function for getting the orcs attack
int Orc::attack()
{
		srand(time(NULL));
		int attack = (((rand() % 100) + 1) + m_strength) + 1;	//calculates the damage done
		return attack;
}