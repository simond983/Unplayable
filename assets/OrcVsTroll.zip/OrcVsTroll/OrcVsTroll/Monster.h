#pragma once

class Monster
{
public:
	Monster();	//Initializes the monster

	//Getters
	bool getAlive() const;
	int getEnergy() const;
	int getHealth() const;

	//Setters
	void setHealth(const int health);
	void setEnergy(const int energy);
	void setAlive(const int alive);

	//Pure virtual attack 
	virtual int attack() = 0;			// virutal function

protected:
	int m_health;	//Health
	bool m_alive;	//Alive
	int m_strength;	//Strength
	int m_energy;	//Energy

private:



};


//Orc class-subclass of monster
class Orc : public Monster
{
public:
	Orc();
	int attack();

private:

};

//Troll class-subclass of monster
class Troll : public Monster
{
public:
	Troll();
	int attack();

private:

};




