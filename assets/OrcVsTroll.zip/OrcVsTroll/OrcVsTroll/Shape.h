#pragma once

class Shape
{
public:
	Shape();
	~Shape();

private:
	int size;
};