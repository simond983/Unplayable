#pragma once

#include "Shape.h"

class Square : Shape
{
public:
	Square();
	~Square();

private:

};

Square::Square()
{
}

Square::~Square()
{
}