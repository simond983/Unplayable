// Rotation.PeterDaly.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "iostream"
#include <windows.h>

void printscreen(int house[][7], int max)
{
	for (int i = 0; i < max; i++)
	{
		for (int e = 0; e < max; e++)
		{
			std::cout << house[i][e] << " ";
		}
		std::cout << "\n";
	}
}

void rotate(int house[][7])
{
	
}


int main()
{
	const int maxNo = 7;
	int house[maxNo][maxNo] = { {1,1,1,1,1,1,1},
								{2,1,1,1,1,1,4},
								{2,2,1,1,1,4,4},
								{2,2,2,1,4,4,4},
								{2,2,1,3,1,4,4},
								{2,1,3,3,3,1,4},
								{1,3,3,3,3,3,1} };

	printscreen(house, maxNo);

	if (GetAsyncKeyState('R') & 0x8000)
	{
		rotate(house);
	}
	return 0;
}

